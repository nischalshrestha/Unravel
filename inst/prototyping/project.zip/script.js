
var data = CodeMirror.fromTextArea($('#data')[0], {
  mode: 'r',
  readOnly: 'nocursor',
  styleActiveLine: false,
  lineNumbers: false,
  gutters: ['data_line'],
  firstLineNumber: 1
});
data.setSize(null, 50);

var group_by_verb_editor = CodeMirror.fromTextArea($('#group_by_verb')[0], {
  mode: 'r',
  readOnly: 'nocursor',
  styleActiveLine: false,
  lineNumbers: false,
  gutters: ['verb1_line'],
  firstLineNumber: 1
});
group_by_verb_editor.setSize(null, 50);
group_by_verb_editor_wrapper = group_by_verb_editor.getWrapperElement();
group_by_glyph = $(".group_by_glyph")[0]
group_by_summary_box = $(".group_by_summary_box")[0]
group_by_summary_box_row = $(".group_by_summary_box_row")[0]
group_by_summary_box_col = $(".group_by_summary_box_col")[0]

var summarise_verb_editor = CodeMirror.fromTextArea($('#summarise_verb')[0], {
  mode: 'r',
  readOnly: 'nocursor',
  styleActiveLine: false,
  lineNumbers: false,
  gutters: ['summarise_verb_editor_line'],
  firstLineNumber: 3
});
summarise_verb_editor.setSize(null, 50);
summarise_verb_editor_wrapper = summarise_verb_editor.getWrapperElement();
summarise_glyph = $(".summarise_glyph")[0]
summarise_summary_box = $(".summarise_summary_box")[0]
summarise_summary_box_row = $(".summarise_summary_box_row")[0]
summarise_summary_box_col = $(".summarise_summary_box_col")[0]

var pivot_wider_verb_editor = CodeMirror.fromTextArea($('#pivot_wider_verb')[0], {
  mode: 'r',
  readOnly: 'nocursor',
  styleActiveLine: false,
  lineNumbers: false,
  gutters: ['pivot_wider_verb_editor_line'],
  firstLineNumber: 3
});
pivot_wider_verb_editor.setSize(null, 50);
pivot_wider_verb_editor_wrapper = pivot_wider_verb_editor.getWrapperElement();
pivot_wider_glyph = $(".pivot_wider_glyph")[0]
pivot_wider_summary_box = $(".pivot_wider_summary_box")[0]
pivot_wider_summary_box_row = $(".pivot_wider_summary_box_row")[0]
pivot_wider_summary_box_col = $(".pivot_wider_summary_box_col")[0]

var mutate_verb_editor = CodeMirror.fromTextArea($('#mutate_verb')[0], {
  mode: 'r',
  readOnly: 'nocursor',
  styleActiveLine: false,
  lineNumbers: false,
  gutters: ['mutate_verb_editor_line'],
  firstLineNumber: 4
});
mutate_verb_editor.setSize(null, 50);
mutate_verb_editor_wrapper = mutate_verb_editor.getWrapperElement()
mutate_glyph = $(".mutate_glyph")[0]
mutate_summary_box = $(".mutate_summary_box")[0]
mutate_summary_box_row = $(".mutate_summary_box_row")[0]
mutate_summary_box_col = $(".mutate_summary_box_col")[0]


function makeMarker() {
  const marker = document.createElement('span');
  marker.className = 'glyphicon glyphicon-move';
  marker.style.paddingLeft = '2px'
  marker.style.paddingRight = '0px'
  marker.style.color = 'grey';
  marker.style.cursor = 'move';
  marker.style.fontSize = '0.8em';
  marker.style.color = '#2c3745';
  marker.style.cursor = '-webkit-grabbing';
  marker.style.float = 'left'
  return marker;
}

/* doc = data.getDoc()
lh = doc.getLineHandle(0);
doc.setGutterMarker(lh, 'data_line', makeMarker()); */

/* doc = verb1.getDoc()
lh = doc.getLineHandle(0);
doc.setGutterMarker(lh, 'verb1_line', makeMarker()); */

/* doc = verb2.getDoc()
lh = doc.getLineHandle(0);
doc.setGutterMarker(lh, 'verb2_line', makeMarker());  */

sortable = Sortable.create(simpleList, {
  /* options */
  onUpdate: function (/**Event*/evt) {
		// same properties as onEnd
    console.log("update");
    console.log("#"+evt.item.id+"_verb");
    
    // TODO update the line firstLineNumber for the particular verbs
    // as needed according to the sorting index update
    
    
    // TODO update the pipe %>% according to whether or not last line or not
    
/*     console.log(verb2.getValue()); */
    console.log(evt.oldIndex);
    console.log(evt.newIndex);
	}
  
});


// TODO update whether or not the line is "dim" if toggle is off

$(function() {

	$('#group_by_toggle').change(function() {
    console.log('group_by_toggle: ' + $(this).prop('checked'));
    if ($(this).prop('checked')) {
      group_by_verb_editor_wrapper.style.opacity = "1";
      group_by_glyph.style.opacity = "1";
      group_by_summary_box.style.opacity = "1";
      group_by_summary_box_row.style.opacity = "1";
      group_by_summary_box_col.style.opacity = "1";
    } else {
      group_by_verb_editor_wrapper.style.opacity = "0.25";
      group_by_glyph.style.opacity = "0.25";
      group_by_summary_box.style.opacity = "0";
      group_by_summary_box_row.style.opacity = "0";
      group_by_summary_box_col.style.opacity = "0";
    }
  })

	$('#summarise_toggle').change(function() {
    console.log('summarise_toggle: ' + $(this).prop('checked'));
    if ($(this).prop('checked')) {
      summarise_verb_editor_wrapper.style.opacity = "1";
      summarise_glyph.style.opacity = "1";
      summarise_summary_box.style.opacity = "1";
      summarise_summary_box_row.style.opacity = "1";
      summarise_summary_box_col.style.opacity = "1";
    } else {
      summarise_verb_editor_wrapper.style.opacity = "0.25";
      summarise_glyph.style.opacity = "0.25";
      summarise_summary_box.style.opacity = "0";
      summarise_summary_box_row.style.opacity = "0";
      summarise_summary_box_col.style.opacity = "0";
    }
  })

  $('#pivot_wider_toggle').change(function() {
    console.log('pivot_wider_toggle: ' + $(this).prop('checked'));
    if ($(this).prop('checked')) {
      pivot_wider_verb_editor_wrapper.style.opacity = "1";
      pivot_wider_glyph.style.opacity = "1";
      pivot_wider_summary_box.style.opacity = "1";
      pivot_wider_summary_box_row.style.opacity = "1";
      pivot_wider_summary_box_col.style.opacity = "1";
    } else {
      pivot_wider_verb_editor_wrapper.style.opacity = "0.25";
      pivot_wider_glyph.style.opacity = "0.25";
      pivot_wider_summary_box.style.opacity = "0";
      pivot_wider_summary_box_row.style.opacity = "0";
      pivot_wider_summary_box_col.style.opacity = "0";
    }
  })
  
  $('#mutate_toggle').change(function() {
    console.log('mutate_toggle: ' + $(this).prop('checked'));
    
    if ($(this).prop('checked')) {
      mutate_verb_editor_wrapper.style.opacity = "1";
      mutate_glyph.style.opacity = "1";
      mutate_summary_box.style.opacity = "1";
      mutate_summary_box_row.style.opacity = "1";
      mutate_summary_box_col.style.opacity = "1";
    } else {
      mutate_verb_editor_wrapper.style.opacity = "0.25";
      mutate_glyph.style.opacity = "0.25";
      mutate_summary_box.style.opacity = "0";
      mutate_summary_box_row.style.opacity = "0";
      mutate_summary_box_col.style.opacity = "0";
    }
  })
})




