var data = CodeMirror.fromTextArea($('#data')[0], {
  mode: 'r',
  readOnly: 'nocursor',
  styleActiveLine: false,
  lineNumbers: false,
  gutters: ['data_line'],
  firstLineNumber: 1
});
data.setSize(null, 50);

var group_by_verb_editor = CodeMirror.fromTextArea($('#group_by_verb')[0], {
  mode: 'r',
  readOnly: 'nocursor',
  styleActiveLine: false,
  lineNumbers: false,
  gutters: ['verb1_line'],
  firstLineNumber: 1
});
group_by_verb_editor.setSize(null, 50);
group_by_verb_editor_wrapper = group_by_verb_editor.getWrapperElement();
group_by_glyph = $(".group_by_glyph")[0]
group_by_summary_box = $(".group_by_summary_box")[0]
group_by_summary_box_row = $(".group_by_summary_box_row")[0]
group_by_summary_box_col = $(".group_by_summary_box_col")[0]

group_by_tippy = tippy(group_by_summary_box, {
  theme: 'light',
  allowHTML: true,
  placement: 'bottom',
  interactive: true,
  delay: [50, 50],
  trigger: 'click'
  /*   triggerTarget: group_by_verb_editor_wrapper */
});
/* group_by_tippy.disable(); */
group_by_tippy.setContent("<strong>Summary</strong>: <code class='code'>group_by</code> has no visible change, but we have internally grouped the dataframe by <span class='internal-change'>year</span>, and <span class='internal-change'>sex</span>. Now we can apply operations on these groups using functions like <code class='code'>summarise</code>.");

/* .addEventListener("onclick", touchHandler, true); */
/* 
 $(document).ready(function () {
   group_by_summary_box.addEventListener("click", function() { 
     console.log("click"); 
    group_by_tippy.enable()
    group_by_tippy.show();
   });
   group_by_summary_box.addEventListener("onMouseOut", function() { 
     console.log("mouse out"); 
    group_by_tippy.hide();
    group_by_tippy.disable();
   });
 }); */

var summarise_verb_editor = CodeMirror.fromTextArea($('#summarise_verb')[0], {
  mode: 'r',
  readOnly: 'nocursor',
  styleActiveLine: false,
  lineNumbers: false,
  gutters: ['summarise_verb_editor_line'],
  firstLineNumber: 3
});
summarise_verb_editor.setSize(null, 50);
summarise_verb_editor_wrapper = summarise_verb_editor.getWrapperElement();
summarise_glyph = $(".summarise_glyph")[0]
summarise_summary_box = $(".summarise_summary_box")[0]
summarise_summary_box_row = $(".summarise_summary_box_row")[0]
summarise_summary_box_col = $(".summarise_summary_box_col")[0]

summarise_tippy = tippy(summarise_summary_box, {
  theme: 'light',
  allowHTML: true,
  placement: 'bottom',
  interactive: true,
  delay: [50, 50],
  trigger: 'click'
  /*   triggerTarget: summarise_summary_box */
});
/* group_by_tippy.disable(); */
summarise_tippy.setContent("<strong>Summary</strong>: <code class='code'>summarise</code> changed the dataframe's shape from <span class='number'>[1.9M x 5]</span> to <span class='visible-change number'>[276 x 3]</span>. It calculated the total count for column <code class='code'>n</code> for (<code class='code'>year</code>, <code class='code'>sex</code>) groups using <code class='code'>sum</code>, which resulted in <span class='visible-change number'>276</span> unique rows. It created a new column <span class='visible-change'>total</span>, kept the <code class='code'>year</code> and <code class='code'>sex</code> columns, and dropped the <code class='code'>name</code>, <code class='code'>n</code>, and <code class='code'>prop</code> columns.");

var pivot_wider_verb_editor = CodeMirror.fromTextArea($('#pivot_wider_verb')[0], {
  mode: 'r',
  readOnly: 'nocursor',
  styleActiveLine: false,
  lineNumbers: false,
  gutters: ['pivot_wider_verb_editor_line'],
  firstLineNumber: 3,
  modifiers: [{
    name: 'offset',
    options: {
      offset: [0, 8],
    },
  }, ]
});
pivot_wider_verb_editor.setSize(null, 50);
pivot_wider_verb_editor_wrapper = pivot_wider_verb_editor.getWrapperElement();
pivot_wider_glyph = $(".pivot_wider_glyph")[0]
pivot_wider_summary_box = $(".pivot_wider_summary_box")[0]
pivot_wider_summary_box_row = $(".pivot_wider_summary_box_row")[0]
pivot_wider_summary_box_col = $(".pivot_wider_summary_box_col")[0]

pivot_wider_tippy = tippy(pivot_wider_summary_box, {
  theme: 'light',
  allowHTML: true,
  placement: 'bottom',
  interactive: true,
  delay: [50, 50],
  trigger: 'click'
});
pivot_wider_tippy.setContent("<strong>Summary</strong>: <code class='code'>pivot_wider</code> changed the dataframe's shape from <span class='number'>[276 x 3]</span> to <span class='visible-change number'>[138 x 3]</span>. It pivoted the dataframe from a long form to a wide form by reorganizing columns (<code class='code'>sex</code>, <code class='code'>total</code>) into (<span class='visible-change'>F</span>, <span class='visible-change'>M</span>), where <span class='visible-change'>F</span> and <span class='visible-change'>M</span> columns hold the values from <code class='code'>total</code>.");

var mutate_verb_editor = CodeMirror.fromTextArea($('#mutate_verb')[0], {
  mode: 'r',
  readOnly: 'nocursor',
  styleActiveLine: false,
  lineNumbers: false,
  gutters: ['mutate_verb_editor_line'],
  firstLineNumber: 4
});
mutate_verb_editor.setSize(null, 50);
mutate_verb_editor_wrapper = mutate_verb_editor.getWrapperElement()
mutate_glyph = $(".mutate_glyph")[0]
mutate_summary_box = $(".mutate_summary_box")[0]
mutate_summary_box_row = $(".mutate_summary_box_row")[0]
mutate_summary_box_col = $(".mutate_summary_box_col")[0]

mutate_tippy = tippy(mutate_summary_box, {
  theme: 'light',
  allowHTML: true,
  placement: 'bottom',
  interactive: true,
  delay: [50, 50],
  trigger: 'click'
});
mutate_tippy.setContent("<strong>Summary</strong>: <code class='code'>mutate</code> changed the dataframe's shape from <span class='number'>[276 x 3]</span> to <span class='visible-change number'>[138 x 3]</span>. It inserted a new column <span class='visible-change'>ratio</span>, which was computed using columns <code class='code'>M</code>, and <code class='code'>F</code>.");

function makeMarker() {
  const marker = document.createElement('span');
  marker.className = 'glyphicon glyphicon-move';
  marker.style.paddingLeft = '2px'
  marker.style.paddingRight = '0px'
  marker.style.color = 'grey';
  marker.style.cursor = 'move';
  marker.style.fontSize = '0.8em';
  marker.style.color = '#2c3745';
  marker.style.cursor = '-webkit-grabbing';
  marker.style.float = 'left'
  return marker;
}

/* doc = data.getDoc()
lh = doc.getLineHandle(0);
doc.setGutterMarker(lh, 'data_line', makeMarker()); */

/* doc = verb1.getDoc()
lh = doc.getLineHandle(0);
doc.setGutterMarker(lh, 'verb1_line', makeMarker()); */

/* doc = verb2.getDoc()
lh = doc.getLineHandle(0);
doc.setGutterMarker(lh, 'verb2_line', makeMarker());  */

/* Obviously you'd already have a list passed from R, which then allows us to dynamically create a Map */
let snippets = new Map();
snippets.set("0", "babynames %>%");
snippets.set("1", "group_by(year, sex) %>%");
snippets.set("2", "summarise(total = sum(n)) %>%");
snippets.set("3", "pivot_wider(names_from = sex, values_from = total) %>%");
snippets.set("4", "mutate(ratio = M / F)");

current_snippets = new Map(snippets);
/* console.log(Array.from(snippets)); */

sortable = Sortable.create(simpleList, {
  /* options */
  onUpdate: function( /**Event*/ evt) {
    // same properties as onEnd
    console.log("update");
    verb_id = "#" + evt.item.id + "_verb";
    console.log(verb_id);
    order = sortable.toArray();
		new_snippets = order.map(o => [o, snippets.get(o)]);
   /*  order.forEach((value, index) => snippets.set(index, value)); */

    
    console.log("old:");
    current_snippets.forEach(function(value, key) {
      console.log(key + ' = ' + value);
    })
    
    current_snippets = new Map(new_snippets);
    console.log("new:");
    current_snippets.forEach(function(value, key) {
      console.log(key + ' = ' + value);
    })
    
    
    // TODO update the line firstLineNumber for the particular verbs
    // as needed according to the sorting index update


    // TODO update the pipe %>% according to whether or not last line or not

    /*     console.log(verb2.getValue()); */
    console.log(evt.oldIndex);
    console.log(evt.newIndex);
  }

});



// TODO update whether or not the line is "dim" if toggle is off

$(function() {

  $('#group_by_toggle').change(function() {
    console.log('group_by_toggle: ' + $(this).prop('checked'));
    if ($(this).prop('checked')) {
    	group_by_tippy.enable();
      group_by_verb_editor_wrapper.style.opacity = "1";
      group_by_glyph.style.opacity = "1";
      group_by_summary_box.style.opacity = "1";
      group_by_summary_box_row.style.opacity = "1";
      group_by_summary_box_col.style.opacity = "1";
    } else {
    	group_by_tippy.disable();
      group_by_verb_editor_wrapper.style.opacity = "0.25";
      group_by_glyph.style.opacity = "0.25";
      group_by_summary_box.style.opacity = "0";
      group_by_summary_box_row.style.opacity = "0";
      group_by_summary_box_col.style.opacity = "0";
    }
  })

  $('#summarise_toggle').change(function() {
    console.log('summarise_toggle: ' + $(this).prop('checked'));
    if ($(this).prop('checked')) {
    	summarise_tippy.enable();
      summarise_verb_editor_wrapper.style.opacity = "1";
      summarise_glyph.style.opacity = "1";
      summarise_summary_box.style.opacity = "1";
      summarise_summary_box_row.style.opacity = "1";
      summarise_summary_box_col.style.opacity = "1";
    } else {
    	summarise_tippy.disable();
      summarise_verb_editor_wrapper.style.opacity = "0.25";
      summarise_glyph.style.opacity = "0.25";
      summarise_summary_box.style.opacity = "0";
      summarise_summary_box_row.style.opacity = "0";
      summarise_summary_box_col.style.opacity = "0";
    }
  })

  $('#pivot_wider_toggle').change(function() {
    console.log('pivot_wider_toggle: ' + $(this).prop('checked'));
    if ($(this).prop('checked')) {
      pivot_wider_tippy.enable();
      pivot_wider_verb_editor_wrapper.style.opacity = "1";
      pivot_wider_glyph.style.opacity = "1";
      pivot_wider_summary_box.style.opacity = "1";
      pivot_wider_summary_box_row.style.opacity = "1";
      pivot_wider_summary_box_col.style.opacity = "1";
    } else {
    	pivot_wider_tippy.disable();
      pivot_wider_verb_editor_wrapper.style.opacity = "0.25";
      pivot_wider_glyph.style.opacity = "0.25";
      pivot_wider_summary_box.style.opacity = "0";
      pivot_wider_summary_box_row.style.opacity = "0";
      pivot_wider_summary_box_col.style.opacity = "0";
    }
  })

  $('#mutate_toggle').change(function() {
    console.log('mutate_toggle: ' + $(this).prop('checked'));

    if ($(this).prop('checked')) {
    	mutate_tippy.enable();
      mutate_verb_editor_wrapper.style.opacity = "1";
      mutate_glyph.style.opacity = "1";
      mutate_summary_box.style.opacity = "1";
      mutate_summary_box_row.style.opacity = "1";
      mutate_summary_box_col.style.opacity = "1";
    } else {
    	mutate_tippy.disable();
      mutate_verb_editor_wrapper.style.opacity = "0.25";
      mutate_glyph.style.opacity = "0.25";
      mutate_summary_box.style.opacity = "0";
      mutate_summary_box_row.style.opacity = "0";
      mutate_summary_box_col.style.opacity = "0";
    }
  })
})

